README
1. The java file "calculateExperience.java" contains the code for calculating the percentage of users who experienced a sentiment type for a business. 
2. To run it, simply copy that file into the java src folder. 
3. Before executing it, give the path of the "test_reviews.json" file which is the input file.
4. The output will print to the console
5. I have included my output in the output folder in the file named "calculateExperience_output.txt".
